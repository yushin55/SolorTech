# 웹 개발자 전달용: 5개 태양광 발전량 예측 모델 (Python)

이 폴더에는 실험 노트북에서 사용한 모델 구조를 재사용하는 Python 학습/추론 코드가 있습니다. 웹 서버는 **요청마다 재학습하지 않고**, 한 번 생성한 `artifacts/`의 모델 파일을 로드해 예측합니다.

## 먼저 확인할 점

- 예측 정답으로 쓰인 발전량은 실측이 아닌 합성 데이터입니다. 합성 발전량 규모에 물리적 오류가 의심되어 이 모델은 `DEMO_ONLY`로 표시합니다.
- 이 코드는 개발자가 웹 화면/API의 연결을 구현할 수 있도록 만든 실험용 인퍼런스 패키지입니다. 투자 판단 결과로 사용하지 마세요.
- LOSO 결과 폴드별 체크포인트를 배포 모델로 쓰지 않습니다. 아래 학습 스크립트는 실험과 같은 구조로 전체 전달 데이터에 다시 적합한 5개 데모 아티팩트를 만듭니다.
- 실제 발전량 자료로 다시 학습할 때는 데이터 준비 함수의 타깃 열을 실측 발전량으로 연결하고, 새 데이터로 재검증한 뒤 `DEMO_ONLY` 표시를 제거할지 결정해야 합니다.

## 파일

- `model_bundle.py`: KMA CSV 읽기, 학습용 월별 데이터 구성, 다섯 모델 적합·저장, 월별 인퍼런스 함수
- `train_artifacts.py`: 데모 모델 아티팩트 생성 명령
- `api.py`: FastAPI 예시 `/api/forecast/monthly` 엔드포인트
- `requirements.txt`: Python 의존성
- `sample_request.json`: 웹 프런트엔드가 보낼 요청 예시

## 다섯 모델과 모델별 실제 입력

1. **Seasonal Baseline** — 실험과 같이 학습 사이트의 월별 용량당 발전량 평균을 이용합니다. 추론에는 월과 DC 용량만 씁니다. 기상/좌표/각도/모듈 정보는 모델 입력이 아닙니다.
2. **Ridge** — `capacity_kwp`, 위도·경도, 경사각, 남향 기준 방위각, 월 sin/cos, 사용 가능한 KMA 월별 변수, `site_id` 범주형 변수.
3. **Hist Gradient Boosting** — Ridge와 같은 입력; 실험의 트리 하이퍼파라미터를 그대로 씁니다.
4. **Random Forest** — Ridge와 같은 입력; 실험의 트리 하이퍼파라미터를 그대로 씁니다.
5. **SARIMAX** — 월별 용량당 발전량 시계열, 월 sin/cos, 학습 중 변동성이 확인된 KMA 월별 기상 외생변수. 예측 발전량은 용량당 예측에 DC 용량을 곱합니다. 모듈 종류·각도·좌표는 현재 실험 SARIMAX 구조의 입력이 아닙니다.

모델이 실제로 학습에 쓰지 않는 입력을 억지로 넣지는 않습니다. 요청 JSON은 공통 설비/후보지 필드를 전달하고, `predict_monthly()`가 선택 모델에 필요한 입력만 사용합니다.

## 입력 파일 위치

Google Drive에 아래 구조로 둡니다.

```text
MyDrive/AItech/
├── 합성데이터/
│   ├── 합성_발전량_일별_물리시뮬레이션_20230401_20260731.csv
│   └── 합성_후보지_설비정보_시뮬레이션.csv
└── 지상관측데이터/
    ├── 지상관측데이터_서울.csv
    ├── 지상관측데이터_대전.csv
    └── ... (노트북에서 읽은 총 12개 파일)
```

ASOS 일자료 파일은 상단 설명행 5개를 건너뛰고 `cp949` CSV로 읽습니다. 기상 월값은 일자료의 월평균이며, 열 이름과 단위는 `model_bundle.py`의 `WEATHER_COLUMNS` 및 `read_kma_asos_daily()`에 있습니다.

## 데모 아티팩트 생성

Google Colab 또는 개발 백엔드 환경에 Python 의존성을 설치한 뒤 패키지 폴더에서 실행합니다.

```bash
python -m pip install -r requirements.txt
python train_artifacts.py \
  --generation "/path/to/합성_발전량_일별_물리시뮬레이션_20230401_20260731.csv" \
  --metadata "/path/to/합성_후보지_설비정보_시뮬레이션.csv" \
  --weather-dir "/path/to/지상관측데이터" \
  --output-dir "artifacts" \
  --seed 42 \
  --allow-demo-synthetic-target
```

마지막 플래그는 합성 타깃으로 만든 데모 전용 모델임을 확인하는 옵션입니다. 결과 `artifacts/`에는 `seasonal_baseline.joblib`, `ridge.joblib`, `hist_gradient_boosting.joblib`, `random_forest.joblib`, `sarimax.joblib`, `manifest.json`이 만들어집니다. 실제 데이터로 바꾸기 전까지 투자판단 기능에 연결하지 않습니다.

## API 실행

```bash
uvicorn api:app --host 0.0.0.0 --port 8000
```

서버 실행 위치에서 `PV_MODEL_ARTIFACT_DIR=artifacts`를 설정합니다. 기상자료 파일 탐색과 좌표-관측소 대응은 웹 백엔드의 후보지/기상 단계에서 처리한 뒤 월별 평균으로 API에 전달합니다. 브라우저에서 직접 CSV 경로나 API 인증키를 다루지 않습니다.

## API 계약 및 예측 기간

`sample_request.json`은 입력 예시입니다. `azimuth_deg_from_south`는 남향 0°, 서향 양수/동향 음수의 convention을 씁니다. 예측 응답의 `predicted_generation_kwh`는 월별 kWh입니다.

- SARIMAX는 학습 시계열 다음 달부터 끊김 없는 월별 입력을 요구합니다. 현재 학습 자료가 2026-07까지라면 미래 예측은 2026-08부터 시작해야 합니다.
- SARIMAX에는 미래 각 달의 날씨가 필요합니다. 과거 관측 파일은 미래 날씨가 아니므로 KMA 예보 또는 기후평년 월자료로 구성해야 합니다.
- `seasonal_baseline`은 날씨 값을 받더라도 사용하지 않습니다. 이는 실험 구조 그대로입니다.
- 전체 매출·공사비 계산은 이 API 범위가 아닙니다. 월별 발전량 합계만 반환합니다.

## 실험 모델 구조

- Ridge: `alpha=10`, 수치형 결측 중앙값 대체 + 표준화, `site_id` 원핫 인코딩
- Hist Gradient Boosting: `max_iter=150`, `learning_rate=0.05`, `max_leaf_nodes=15`, `l2_regularization=1.0`
- Random Forest: `n_estimators=300`, `min_samples_leaf=3`, `max_features=0.8`
- SARIMAX: `(1,0,0)`, 비계절 `(0,0,0,0)`, 상수 추세, 학습 시 외생변수 표준화
- Seasonal Baseline: 월별 용량당 평균 수율 × 요청 설비용량

이번 실험의 검증 fold 체크포인트와 웹 배포용 전체자료 재적합 데모 아티팩트는 용도가 다릅니다. 운영 전에 반드시 실측 발전량으로 재학습·검증하고 아티팩트 버전 및 단위를 고정해야 합니다.
