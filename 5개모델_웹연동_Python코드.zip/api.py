from pathlib import Path
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Literal

from model_bundle import predict_monthly

ARTIFACT_DIR = Path(os.environ.get("PV_MODEL_ARTIFACT_DIR", "artifacts"))
app = FastAPI(title="PV Monthly Generation Demo API", version="0.1.0")

class ForecastRequest(BaseModel):
    model_name: Literal["seasonal_baseline", "ridge", "hist_gradient_boosting", "random_forest", "sarimax"]
    candidate: dict[str, Any]
    design: dict[str, Any]
    # monthly weather means, keyed by YYYY-MM, using model_bundle.py's w_* field names
    monthly_weather: list[dict[str, Any]]

@app.post("/api/forecast/monthly")
def forecast_monthly(request: ForecastRequest):
    try:
        months = predict_monthly(
            request.model_name, ARTIFACT_DIR,
            request.candidate, request.design, request.monthly_weather,
        )
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Forecast failed: {type(exc).__name__}: {exc}") from exc
    total_kwh = sum(row["predicted_generation_kwh"] for row in months)
    return {
        "model_name": request.model_name,
        "model_status": "DEMO_ONLY_UNVALIDATED",
        "months": months,
        "total_generation_kwh": total_kwh,
        "total_generation_mwh": total_kwh / 1000.0,
        "warning": "Synthetic training target; do not use for investment decisions.",
    }
