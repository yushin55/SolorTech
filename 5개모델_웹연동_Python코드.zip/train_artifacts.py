from pathlib import Path
import argparse

from model_bundle import build_monthly_training_data, train_and_save_all

parser = argparse.ArgumentParser(description="Fit all five PV demo models and export artifacts")
parser.add_argument("--generation", required=True, help="Daily generation CSV")
parser.add_argument("--metadata", required=True, help="Site/design metadata CSV")
parser.add_argument("--weather-dir", required=True, help="Directory containing 지상관측데이터_지역명.csv files")
parser.add_argument("--output-dir", default="artifacts", help="Artifact export directory")
parser.add_argument("--seed", type=int, default=42)
parser.add_argument(
    "--allow-demo-synthetic-target", action="store_true",
    help="Required acknowledgement: this exports demo-only models trained on synthetic targets.",
)
args = parser.parse_args()
if not args.allow_demo_synthetic_target:
    parser.error("Current target is synthetic/unvalidated. Add --allow-demo-synthetic-target only for a labelled demo.")

monthly = build_monthly_training_data(args.generation, args.metadata, args.weather_dir)
paths = train_and_save_all(monthly, args.output_dir, seed=args.seed)
print("Monthly rows:", len(monthly), "sites:", monthly.site_id.nunique())
for name, path in paths.items():
    print(name, "->", path)
print("WARNING: current target is synthetic and has not been approved for investment forecasting.")
