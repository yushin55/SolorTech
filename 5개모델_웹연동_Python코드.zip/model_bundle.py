"""Model implementations matching the experiment notebook's five model families."""
from __future__ import annotations

import json
import unicodedata
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from statsmodels.tsa.statespace.sarimax import SARIMAX

WEATHER_COLUMNS = {
    "w_temperature_avg_c": 2,
    "w_temperature_max_c": 3,
    "w_temperature_min_c": 5,
    "w_relative_humidity_avg_pct": 7,
    "w_relative_humidity_min_pct": 8,
    "w_cloud_amount_tenths": 10,
    "w_sunshine_hours": 11,
    "w_daylight_duration_hours": 12,
    "w_global_irradiation_mj_m2_day": 13,
    "w_max_60min_irradiation_mj_m2": 14,
}

SITE_WEATHER_CITY = {
    "ASAN": "천안", "CHEONAN": "천안", "DAEJEON": "대전", "SEOUL": "서울",
    "INCHEON": "인천", "SUWON": "수원", "SEOSAN": "서산", "CHEONGJU": "청주",
    "DAEGU": "대구", "JEONJU": "전주", "GWANGJU": "광주", "BUSAN": "부산",
    "GANGNEUNG": "강릉",
}


def read_kma_asos_daily(path: str | Path) -> pd.DataFrame:
    """Read the provided ASOS daily CSV (5 descriptive rows, then comma-separated rows)."""
    path = Path(path)
    raw = pd.read_csv(path, skiprows=5, header=None, encoding="cp949", low_memory=False)
    if raw.shape[1] < 13:
        raise ValueError(f"ASOS CSV has fewer than 13 columns: {path}")
    frame = pd.DataFrame({
        "date": pd.to_datetime(raw.iloc[:, 0].astype(str).str.strip(), format="%Y%m%d", errors="coerce")
    })
    for name, idx in WEATHER_COLUMNS.items():
        if idx < raw.shape[1]:
            values = pd.to_numeric(raw.iloc[:, idx], errors="coerce")
            frame[name] = values.replace([-99.9, -99.0, -999.0, 9999.0], np.nan)
        else:
            frame[name] = np.nan
    frame = frame.dropna(subset=["date"]).copy()
    frame["date"] = frame["date"].dt.normalize()
    if "w_sunshine_hours" in frame and "w_daylight_duration_hours" in frame:
        frame["w_sunshine_hours"] = frame["w_sunshine_hours"].clip(lower=0)
        frame["w_daylight_duration_hours"] = frame["w_daylight_duration_hours"].clip(lower=0)
        frame["w_sunshine_hours"] = np.minimum(
            frame["w_sunshine_hours"], frame["w_daylight_duration_hours"]
        )
    if frame["date"].duplicated().any():
        frame = frame.groupby("date", as_index=False).mean(numeric_only=True)
    if frame.empty:
        raise ValueError(f"No valid YYYYMMDD rows found in {path}")
    return frame


def build_monthly_training_data(
    generation_csv: str | Path,
    metadata_csv: str | Path,
    weather_dir: str | Path,
) -> pd.DataFrame:
    """Join synthetic daily targets to actual KMA weather and aggregate to site-month."""
    generation = pd.read_csv(generation_csv, encoding="utf-8-sig", low_memory=False)
    metadata = pd.read_csv(metadata_csv, encoding="utf-8-sig")
    metadata = metadata.rename(columns={
        "위도": "latitude", "경도": "longitude",
        "합성_DC설비용량_kWp": "capacity_kwp", "경사각_deg": "tilt_deg",
        "방위각_deg_남향180": "azimuth_deg_남향180",
    })
    need = {"site_id", "지역", "date", "일별_합성발전량_kWh"}
    if need - set(generation.columns):
        raise ValueError(f"Generation input missing columns: {sorted(need - set(generation.columns))}")
    site_need = {"site_id", "지역", "latitude", "longitude", "capacity_kwp", "tilt_deg", "azimuth_deg_남향180"}
    if site_need - set(metadata.columns):
        raise ValueError(f"Metadata input missing columns: {sorted(site_need - set(metadata.columns))}")
    weather_dir = Path(weather_dir)
    paths = list(weather_dir.rglob("*.csv"))
    normalized_prefix = unicodedata.normalize("NFC", "지상관측데이터_")
    by_city: dict[str, pd.DataFrame] = {}
    for path in paths:
        stem = unicodedata.normalize("NFC", path.stem)
        if stem.casefold().startswith(normalized_prefix.casefold()):
            by_city[stem[len(normalized_prefix):]] = read_kma_asos_daily(path)
    if not by_city:
        raise FileNotFoundError(f"No 지상관측데이터_지역명.csv files found under {weather_dir}")

    generation["date"] = pd.to_datetime(generation["date"], errors="coerce").dt.normalize()
    generation["일별_합성발전량_kWh"] = pd.to_numeric(generation["일별_합성발전량_kWh"], errors="coerce")
    joined_parts = []
    for _, site in metadata.iterrows():
        site_id = str(site["site_id"])
        city = SITE_WEATHER_CITY.get(site_id)
        if city is None:
            raise ValueError(f"No weather station mapping for site_id={site_id}")
        if city not in by_city:
            raise FileNotFoundError(f"Required KMA CSV missing: 지상관측데이터_{city}.csv")
        part = generation.loc[generation["site_id"].astype(str) == site_id].copy()
        part = part.merge(by_city[city], on="date", how="left", validate="many_to_one")
        part["기상자료_지역"] = city
        joined_parts.append(part)
    daily = pd.concat(joined_parts, ignore_index=True)
    daily = daily.rename(columns={"일별_합성발전량_kWh": "y_daily_kwh"})
    daily = daily.merge(metadata, on=["site_id", "지역"], how="left", suffixes=("", "_meta"))
    if "capacity_kwp" not in daily:
        daily["capacity_kwp"] = daily["합성_DC설비용량_kWp"]
    else:
        daily["capacity_kwp"] = daily["capacity_kwp"].fillna(daily.get("합성_DC설비용량_kWp"))
    if "latitude" not in daily:
        daily["latitude"] = daily["위도"]
    if "longitude" not in daily:
        daily["longitude"] = daily["경도"]
    if "tilt_deg" not in daily:
        daily["tilt_deg"] = daily["경사각_deg"]
    daily["azimuth_deg"] = pd.to_numeric(daily["방위각_deg_남향180"], errors="coerce") - 180.0
    daily["month"] = daily["date"].dt.to_period("M").astype(str)
    weather_cols = [c for c in WEATHER_COLUMNS if c in daily and daily[c].notna().any()]
    monthly_target = daily.groupby(["site_id", "지역", "month"], as_index=False).agg(
        y_kwh=("y_daily_kwh", "sum"), capacity_kwp=("capacity_kwp", "first"),
        latitude=("latitude", "first"), longitude=("longitude", "first"),
        tilt_deg=("tilt_deg", "first"), azimuth_deg=("azimuth_deg", "first"),
    )
    weather_monthly = daily.groupby(["site_id", "month"], as_index=False)[weather_cols].mean()
    data = monthly_target.merge(weather_monthly, on=["site_id", "month"], validate="one_to_one")
    data["month_num"] = pd.PeriodIndex(data["month"], freq="M").month
    data["month_sin"] = np.sin(2 * np.pi * data["month_num"] / 12)
    data["month_cos"] = np.cos(2 * np.pi * data["month_num"] / 12)
    data["site_id"] = data["site_id"].astype(str)
    if data.empty or data["y_kwh"].isna().any():
        raise ValueError("Monthly training data is empty or contains missing targets")
    return data


def _feature_columns(data: pd.DataFrame) -> tuple[list[str], list[str], list[str]]:
    weather = [c for c in WEATHER_COLUMNS if c in data.columns and data[c].notna().any()]
    numeric = ["capacity_kwp", "latitude", "longitude", "tilt_deg", "azimuth_deg", "month_sin", "month_cos"] + weather
    categorical = ["site_id"]
    return numeric, categorical, weather


def _preprocessor(numeric_features: list[str], categorical_features: list[str], scale: bool) -> ColumnTransformer:
    steps: list[tuple[str, Any]] = [("imputer", SimpleImputer(strategy="median", keep_empty_features=True))]
    if scale:
        steps.append(("scaler", StandardScaler()))
    return ColumnTransformer(
        transformers=[
            ("num", Pipeline(steps), numeric_features),
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ], sparse_threshold=0, remainder="drop",
    )


def train_and_save_all(data: pd.DataFrame, output_dir: str | Path, seed: int = 42) -> dict[str, Path]:
    """Fit the five notebook model structures on all supplied rows and save artifacts.

    This creates full-data demo artifacts, not LOSO validation checkpoints. The supplied
    target data must be corrected/approved before these artifacts are used for investment decisions.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    numeric, categorical, weather = _feature_columns(data)
    X, y = data[numeric + categorical], data["y_kwh"].astype(float)
    saved: dict[str, Path] = {}

    # Seasonal Baseline: same month-of-year mean specific yield × candidate capacity.
    temp = data.assign(_specific_yield=data["y_kwh"] / data["capacity_kwp"].clip(lower=1e-8))
    baseline = {
        "month_yield": temp.groupby("month_num")["_specific_yield"].mean().to_dict(),
        "fallback_yield": float(temp["_specific_yield"].mean()),
    }
    saved["seasonal_baseline"] = output_dir / "seasonal_baseline.joblib"
    joblib.dump(baseline, saved["seasonal_baseline"])

    models = {
        "ridge": Pipeline([("prep", _preprocessor(numeric, categorical, True)), ("model", Ridge(alpha=10.0))]),
        "hist_gradient_boosting": Pipeline([
            ("prep", _preprocessor(numeric, categorical, False)),
            ("model", HistGradientBoostingRegressor(
                max_iter=150, learning_rate=0.05, max_leaf_nodes=15,
                l2_regularization=1.0, random_state=seed,
            )),
        ]),
        "random_forest": Pipeline([
            ("prep", _preprocessor(numeric, categorical, False)),
            ("model", RandomForestRegressor(
                n_estimators=300, min_samples_leaf=3, max_features=0.8,
                n_jobs=-1, random_state=seed,
            )),
        ]),
    }
    for name, model in models.items():
        model.fit(X, y)
        path = output_dir / f"{name}.joblib"
        joblib.dump(model, path)
        saved[name] = path

    # SARIMAX: pooled monthly specific yield, same AR(1)/trend/exog structure as notebook.
    exog_cols = ["month_sin", "month_cos"] + weather
    pooled_y = temp.groupby("month")["_specific_yield"].mean().sort_index()
    pooled_exog = data.groupby("month")[exog_cols].mean().reindex(pooled_y.index)
    medians = pooled_exog.median().fillna(0)
    pooled_exog = pooled_exog.fillna(medians)
    # Remove constants from exogenous inputs to avoid collinearity with trend='c'.
    varying_cols = [c for c in exog_cols if pooled_exog[c].nunique(dropna=True) > 1]
    if not varying_cols:
        raise ValueError("SARIMAX has no varying exogenous columns after cleaning")
    exog_cols = varying_cols
    sarimax_exog = pooled_exog[exog_cols]
    exog_mean = sarimax_exog.mean()
    exog_std = sarimax_exog.std().replace(0, 1).fillna(1)
    scaled_exog = (sarimax_exog - exog_mean) / exog_std
    fitted = SARIMAX(
        pooled_y.astype(float).to_numpy(), exog=scaled_exog.to_numpy(dtype=float),
        order=(1, 0, 0), seasonal_order=(0, 0, 0, 0), trend="c",
        enforce_stationarity=False, enforce_invertibility=False,
    ).fit(disp=False, maxiter=200)
    sarimax_artifact = {
        "results": fitted, "exog_cols": exog_cols, "medians": medians[exog_cols],
        "exog_mean": exog_mean, "exog_std": exog_std,
        "last_month": str(pooled_y.index.max()),
        "weather_features": weather,
    }
    saved["sarimax"] = output_dir / "sarimax.joblib"
    joblib.dump(sarimax_artifact, saved["sarimax"])

    manifest = {
        "seed": seed, "model_names": list(saved), "numeric_features": numeric,
        "categorical_features": categorical, "weather_features": weather,
        "fit_rows": int(len(data)), "fit_sites": int(data["site_id"].nunique()),
        "fit_months": [str(data["month"].min()), str(data["month"].max())],
        "target_notice": "Synthetic target; demo only until validated/corrected.",
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return saved


def predict_monthly(model_name: str, artifact_dir: str | Path, candidate: dict[str, Any], design: dict[str, Any], monthly_weather: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Run one model for requested month rows. Weather rows are monthly means in notebook units."""
    artifact_dir = Path(artifact_dir)
    if not monthly_weather:
        raise ValueError("monthly_weather must contain at least one requested month")
    frame = pd.DataFrame(monthly_weather).copy()
    if "month" not in frame:
        raise ValueError("Each weather row must include month='YYYY-MM'")
    frame["month"] = frame["month"].astype(str)
    periods = pd.PeriodIndex(frame["month"], freq="M")
    frame["month_num"] = periods.month
    frame["month_sin"] = np.sin(2 * np.pi * frame["month_num"] / 12)
    frame["month_cos"] = np.cos(2 * np.pi * frame["month_num"] / 12)
    frame["capacity_kwp"] = float(design["dc_capacity_kwp"])
    frame["latitude"] = float(candidate["latitude"])
    frame["longitude"] = float(candidate["longitude"])
    frame["tilt_deg"] = float(design.get("tilt_deg", 0))
    frame["azimuth_deg"] = float(design.get("azimuth_deg_from_south", 0))
    frame["site_id"] = str(candidate.get("site_id", "NEW_SITE"))

    if model_name == "seasonal_baseline":
        artifact = joblib.load(artifact_dir / "seasonal_baseline.joblib")
        yields = np.array([artifact["month_yield"].get(int(m), artifact["fallback_yield"]) for m in periods.month])
        pred = np.maximum(0, yields * frame["capacity_kwp"].to_numpy())
    elif model_name == "sarimax":
        artifact = joblib.load(artifact_dir / "sarimax.joblib")
        exog_cols = artifact["exog_cols"]
        requested_periods = pd.PeriodIndex(frame["month"], freq="M")
        last_period = pd.Period(artifact["last_month"], freq="M")
        expected_periods = pd.period_range(last_period + 1, periods=len(frame), freq="M")
        if not requested_periods.equals(expected_periods):
            raise ValueError(
                f"SARIMAX needs consecutive future months beginning {expected_periods[0]}; "
                "supply forecast weather for every month in between."
            )
        missing = [c for c in exog_cols if c not in frame.columns]
        if missing:
            raise ValueError(f"SARIMAX monthly weather input missing columns: {missing}")
        exog = frame[exog_cols].apply(pd.to_numeric, errors="coerce").fillna(artifact["medians"])
        scaled = (exog - artifact["exog_mean"]) / artifact["exog_std"]
        forecast = artifact["results"].get_forecast(steps=len(frame), exog=scaled.to_numpy(dtype=float))
        pred = np.maximum(0, np.asarray(forecast.predicted_mean, dtype=float) * frame["capacity_kwp"].to_numpy())
    else:
        if model_name not in {"ridge", "hist_gradient_boosting", "random_forest"}:
            raise ValueError(f"Unsupported model_name: {model_name}")
        model = joblib.load(artifact_dir / f"{model_name}.joblib")
        manifest = json.loads((artifact_dir / "manifest.json").read_text(encoding="utf-8"))
        feature_cols = manifest["numeric_features"] + manifest["categorical_features"]
        for c in feature_cols:
            if c not in frame.columns:
                frame[c] = np.nan
        pred = np.maximum(0, model.predict(frame[feature_cols]))

    return [
        {"month": month, "predicted_generation_kwh": float(value),
         "predicted_generation_mwh": float(value) / 1000.0,
         "quality_label": "DEMO_ONLY_SYNTHETIC_TARGET_NOT_FOR_INVESTMENT"}
        for month, value in zip(frame["month"], pred)
    ]
